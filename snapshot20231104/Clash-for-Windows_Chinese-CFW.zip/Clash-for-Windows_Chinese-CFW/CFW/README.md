### 众所周知 Clash for Windows 原版仓库已经删库跑路，以下是一些原版包的存档
